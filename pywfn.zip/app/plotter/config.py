BOND_WIDTH=0.2 #键的宽度
