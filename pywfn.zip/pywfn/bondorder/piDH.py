"""
轨道分解法+HMO计算π键级
"""
from ..base import Mol,Atom,Bond
import numpy as np
from .. import utils
from typing import *


class Calculator:
    def __init__(self,mol:Mol) -> None:
        self.mol=mol
        self.mol.create_bonds()

    def get_order(self, center:Atom, around:Atom, orbital:int, direction):  # 计算一个轨道的键级
        '''计算两个原子间每个轨道的键级
        中心原子，相邻原子，轨道，方向'''
        if around.symbol=='H':
            return 0
        if np.linalg.norm(direction)==0:
            return 0
        As=self.mol.As[orbital]
        oe=1 if self.mol.isSplitOrbital else 2

        centerPos=center.coord
        aroundPos=around.coord
        bondVector=aroundPos-centerPos
        crossVector=np.cross(utils.normalize(bondVector),utils.normalize(direction))
        
        # centerTs=center.pLayersTs(orbital).copy()
        # aroundTs=around.pLayersTs(orbital).copy()
        centerTs=center.OC[:,orbital].copy()
        aroundTs=around.OC[:,orbital].copy()
        if np.linalg.norm(centerTs)==0 or np.linalg.norm(aroundTs)==0:
            return 0
        
        centerPsProj=center.get_pLayersProjection(direction, orbital) # 先计算投影
        aroundPsProj=around.get_pLayersProjection(direction, orbital)
        centerPTS=np.concatenate(centerPsProj)
        aroundPTS=np.concatenate(aroundPsProj)
        # 根据投影的向量判断成键还是反键
        # angle=utils.vector_angle(centerPsProj[0],aroundPsProj[0])
        # unit=1 if angle<0.5 else -1
        # centerTs[self.centerPIdx]=centerPTS
        # aroundTs[self.aroundPIdx]=aroundPTS
        # centerSqrt=np.sqrt(np.sum(centerTs**2,axis=0))
        # aroundSqrt=np.sqrt(np.sum(aroundTs**2,axis=0))
        # centerRes=centerSqrt/As
        # aroundRes=aroundSqrt/As
        
        # order=centerRes*aroundRes*oe
        # return order


        nx=bondVector
        ny=crossVector
        nz=direction
        centerRes=utils.coordTrans(nx,ny,nz, centerPsProj)
        aroundRes=utils.coordTrans(nx,ny,nz, aroundPsProj)

        centerPZs=[each[-1] for each in centerRes]
        aroundPZs=[each[-1] for each in aroundRes]
        # angle=utils.vector_angle(center.get_orbitalDirection(orbital),around.get_orbitalDirection(orbital))
        # unit=1 if angle<0.5 else -1
        # unit=sum([cpz*apz for cpz,apz in zip(centerPZs,aroundPZs)]) #成键还是反键
        # unit=unit/abs(unit)

        pOrder=sum([cpz*apz/As for cpz,apz in zip(centerPZs,aroundPZs)])*oe
        return pOrder
        # return order

    def get_orders(self,center:Atom,around:Atom,orbitals:List[int],direction):
        """计算每两个原子之间的键级"""
        orders=[self.get_order(center,around,orbital,direction) for orbital in orbitals] # 所有的占据轨道都计算键级
        return orders

    def calculate(self,centerAtom:Atom,aroundAtom:Atom) -> dict:
        """指定一个键，计算该键的键级"""
        self.centerPIdx=[i for i,l in enumerate(centerAtom.layers) if 'P' in l] #原子的序数
        self.aroundPIdx=[i for i,l in enumerate(aroundAtom.layers) if 'P' in l]
        self.mol.create_bonds()
        O_orbitals=self.mol.O_orbitals
        normal=centerAtom.get_Normal(aroundAtom) # 原子的法向量
        if len(centerAtom.neighbors)==3: # 如果原子有法向量(sp2)
            orders=self.get_orders(centerAtom,aroundAtom,O_orbitals,normal)
            return {
                "type":0,
                "data":{
                    "orders":orders,
                    "order":sum(orders)
                }
            }
        else: # 如果没有法向量的话，则需要找轨道方向作为基础方向
            # 从高到低计算轨道方向，遇到有垂直于键轴的则作为轨道方向
            orbitalDirection=None
            for o in O_orbitals[::-1]:
                orbitalDirection=centerAtom.get_orbitalDirection(o)
                if np.linalg.norm(orbitalDirection)==0:
                    continue
                bondDirection=self.mol.get_bond(centerAtom.idx, aroundAtom.idx).bondVector()
                if utils.vector_angle(orbitalDirection, bondDirection,trans=True)>0.4: # 夹角要很大
                    break
            if orbitalDirection is not None:
                orders1=self.get_orders(centerAtom,aroundAtom,O_orbitals,orbitalDirection)
                crossDirection=np.cross(orbitalDirection, bondDirection)
                orders2=self.get_orders(centerAtom,aroundAtom,O_orbitals,crossDirection)
                return {
                    "type":1,
                    "data":{
                        "orders":[orders1,orders2],
                        "order":[sum(orders1),sum(orders2)]
                    }
                }