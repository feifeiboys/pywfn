"""
公用的工具函数
"""
import numpy as np
from typing import *
from ..base import Atom
from ..utils import vector_angle
import numpy as np
import time
def CM2PM(CM,orbital:List[int],oe:int):
    """
    根据系数矩阵构建密度矩阵
    CM:系数矩阵,如果是开壳层的话,列数是行数的两倍[n,n]/[n,2n]
    n:分子轨道占据电子数
    """
    PMs=CM2PMs(CM,orbital,oe)
    return np.sum(PMs,axis=0)

def CM2PMs(CM,orbital:List[int],oe:int):
    """
    构建三维密度矩阵，不要空轨道，形状为[占据轨道数,原子轨道数,原子轨道数]
    """
    t0=time.time()
    l,c=CM.shape # CM行数和列数,原子轨道数量和分子轨道数量，分子轨道数量可能会是原子轨道数量的2倍
    A=(CM[:,orbital].T)[:,:,np.newaxis]
    B=(CM[:,orbital].T)[:,np.newaxis,:]
    t1=time.time()
    return A@B #用矩阵乘法的形式直接构建矩阵可比逐元素计算多了

    PMs=np.zeros(shape=(c,l,l)) #[n,n,n] 三维矩阵，第0个维度是分子轨道的序数
    for j in range(c):
        ci=CM[:,j].reshape(-1,1) #[n,1]
        cj=CM[:,j].reshape(1,-1) #[1,n]
        e=n[j]
        PMs[j,:,:]=ci@cj*e
    t2=time.time()
    print('两者时间',t1-t0,t2-t1)
    return PMs

def judgeOrbital(centerAtom:Atom,aroundAtom:Atom,orbital:int,normal)->int:
    """
    判断一个轨道是否为π轨道,几何方法
    centerAtom,aroundAtom:原子对象
    orbital:分子轨道序数
    normal:原子法向量[其实可以是任意方向]
    """
    if aroundAtom.symbol=='H' or centerAtom.symbol=='H':
        return 0
    # 1. 根据s轨道和p轨道的贡献
    sContCenter=centerAtom.get_sCont(orbital)
    sContAround=aroundAtom.get_sCont(orbital)
    if sContCenter>0.01 or sContAround>0.01:
        return 0
    # 2. p轨道的方向要处在垂直分子平面方向
    cenDir=centerAtom.get_orbitalDirection(orbital)
    aroDir=aroundAtom.get_orbitalDirection(orbital)
    centerAngle=vector_angle(cenDir,normal)
    aroundAngle=vector_angle(aroDir,normal)
    if abs(0.5-centerAngle)>0.2 or abs(0.5-aroundAngle)>0.2:
        return 0
    # 以上两个条件都满足的可以认为是π轨道
    if (0.5-centerAngle)*(0.5-aroundAngle)>0:
        return 1
    else:
        return -1

def judgeOrbital_(centerAtom:Atom,aroundAtom:Atom,orbital:int,normal)-> int:
    """判断某一个键的分子轨道是不是π轨道,成键返回1，反键返回-1，否则返回0"""
    

    centerTs=centerAtom.pLayersTs(orbital)
    aroundTs=aroundAtom.pLayersTs(orbital)
    centerPs=[np.array(centerTs[i:i+3]) for i in range(0,len(centerTs),3)]
    aroundPs=[np.array(aroundTs[i:i+3]) for i in range(0,len(aroundTs),3)]
    normal=centerAtom.get_Normal(aroundAtom)
    centerPs_=centerAtom.get_pLayersProjection(normal, orbital) # 先计算投影
    aroundPs_=aroundAtom.get_pLayersProjection(normal, orbital)
    centerPs,centerPs_=np.array(centerPs),np.array(centerPs_) # 将系数转为数组
    aroundPs,aroundPs_=np.array(aroundPs),np.array(aroundPs_)
    centerPs,centerPs_=centerPs.sum(axis=0),centerPs_.sum(axis=0) # 将不同组的p求和
    aroundPs,aroundPs_=aroundPs.sum(axis=0),aroundPs_.sum(axis=0)
    centerL,centerL_=np.linalg.norm(centerPs),np.linalg.norm(centerPs_) #p轨道系数组成向量的长度
    aroundL,aroundL_=np.linalg.norm(aroundPs),np.linalg.norm(aroundPs_)
    # centerRatio=np.linalg.norm(centerPs_)/np.linalg.norm(centerPs) # 投影后与投影前的比例
    # aroundRatio=np.linalg.norm(aroundPs_)/np.linalg.norm(aroundPs) 
    centerRatio=np.divide(centerL_,centerL,out=np.zeros_like(centerL),where=centerL!=0)
    aroundRatio=np.divide(aroundL_,aroundL,out=np.zeros_like(aroundL),where=aroundL!=0)

    
    centerScont=centerAtom.get_sContribution(orbital)
    aroundScont=aroundAtom.get_sContribution(orbital)
    # print(orbital,centerScont,aroundScont)
    if centerScont>0.001 or aroundScont>0.001:
        return 0 # s贡献太大的不是

    # centerNormal=centerAtom.get_Normal(aroundAtom) #法向量方向
    # if len(aroundAtom.neighbors)==3:
    #     aroundNormal=aroundAtom.get_Normal(centerAtom)
    # else:
    #     aroundNormal=centerNormal
    # if utils.vector_angle(centerNormal,aroundNormal,trans=True)>0.5:
    #     aroundNormal*=-1

    # centerOrbitalDirection=centerAtom.get_orbitalDirection(orbital) #原子轨道方向
    # aroundOrbitalDirection=aroundAtom.get_orbitalDirection(orbital)
    # if np.linalg.norm(centerOrbitalDirection)==0 or np.linalg.norm(aroundOrbitalDirection)==0:
    #     return 0
    # centerAngle=utils.vector_angle(centerNormal,centerOrbitalDirection,trans=True)
    # aroundAngle=utils.vector_angle(centerNormal,aroundOrbitalDirection,trans=True)

    # if centerAngle<0.2 and aroundAngle<0.2:

    if centerRatio<=0.1 or aroundRatio<=0.1:
        return 0
    if vector_angle(centerPs_,aroundPs_)<=0.5:
        return 1
    else:
        return -1