from .data import Elements
elements=Elements()
from .shell import Shell
# print('pywfn 初始化',__name__)
def runShell():
    shell=Shell()
    shell.home()